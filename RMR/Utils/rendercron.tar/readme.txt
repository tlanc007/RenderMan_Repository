RenderCron.

These scripts are provided free of charge. I do not guarantee their 
reliability. It would be a good idea to check them out first before
committing your precious projects :-)

These scripts were written so as to allow students to indicate to
cron which .rib files they wanted rendered overnight. In our case
this is done through a file manager which adds the name of the .rib
file to a text file called rendlist. Rendlist and the .rib files must
reside in the student subdirectory called render.in. The rendered .tif
files are moved over to another subdirectory called render.out.

The file called niterend contains a list of users, and should be placed
in some easy to maintain place. In our case it resides in root's subdirectory
and is run by root. Note: This may create security problems in an insecure
network. The files niterend2, multirend, and packtiff are placed in 
/usr/local/bin. Cron can be very fussy about absolute paths, so check
that your path to test, mv, xargs, etc matches those of the scripts, and
change if necessary. Add the necessary command to start niterend to your 
crontab.

Packtiff is an (optional) script to change the compression scheme of a .tif 
file if you should need, and calls tiffcp which is provided in Sam Leffler's 
libtiff library - http://www.libtiff.org .

I hope that this is of use to the programming challenged such as myself. Please
e-mail me at gavin@artlite.co.za if you have any comments, improvements, etc.