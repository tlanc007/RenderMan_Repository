#include <stdio.h>
#include "particlemap.h"

int main()
{
struct ParticleMap *map;
struct BalancedParticleMap *bmap;
float pos[3];

map=createParticleMap(100000);
while(scanf("%f,%f,%f\n",pos,pos+1,pos+2)==3)
	{
	//printf("%f,%f,%f\n",pos[0],pos[1],pos[2]);
	//pos[2]*=-1;
	storeParticle(map,pos);
	}
bmap=balanceParticleMap(map);
saveParticleMap(bmap,"particle.part");
destroyParticleMap(bmap);
return 0;
}
