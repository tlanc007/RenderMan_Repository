#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include <sys/stat.h>
#include "shadeop.h"

#ifndef WIN32
#include <alloca.h>
#endif

#include "particlemap.h"


ParticleMap *createParticleMap(int max_particles)
	{
	ParticleMap *map=malloc(sizeof(ParticleMap));
  map->stored_particles = 0;
  map->max_particles = max_particles;

  map->particles = (Particle*)malloc( sizeof( Particle ) * ( max_particles+1 ) );

  if (map->particles == NULL) {
    fprintf(stderr,"Out of memory initializing particle map\n");
    exit(-1);
  }

  map->bbox_min[0] = map->bbox_min[1] = map->bbox_min[2] = 1e8f;
  map->bbox_max[0] = map->bbox_max[1] = map->bbox_max[2] = -1e8f;
  
  return map;
}

void destroyParticleMap(BalancedParticleMap *map)
{
  free(map->particles );
  free(map);
}

 
/* store puts a particle into the flat array that will form
 * the final kd-tree.
 *
 * Call this function to store a particle.
*/
//***************************
void storeParticle(
  ParticleMap *map,
  const float pos[3])
//***************************
{
  int i;
  Particle *node;
  if (map->stored_particles>=map->max_particles)
	{
	Particle *newMap=(Particle*)realloc(map->particles,sizeof(Particle)*(2*map->max_particles+1));
	//printf("increasing map size to %d\n",map->max_particles*2);
	if(newMap==NULL)
		{
		static int done=0;
		if(!done)
			fprintf(stderr,"Particle Map Full\n");
		done=1;
		return;
		}
	map->particles=newMap;
	map->max_particles*=2;
	}

 map->stored_particles++;
 node = &map->particles[map->stored_particles];

  for (i=0; i<3; i++) {
    node->pos[i] = pos[i];

    if (node->pos[i] < map->bbox_min[i])
      map->bbox_min[i] = node->pos[i];
    if (node->pos[i] > map->bbox_max[i])
      map->bbox_max[i] = node->pos[i];
  }
}

// median_split splits the particle array into two separate
// pieces around the median with all particles below the
// the median in the lower half and all particles above
// than the median in the upper half. The comparison
// criteria is the axis (indicated by the axis parameter)
// (inspired by routine in "Algorithms in C++" by Sedgewick)
//*****************************************************************
static void median_split(
  Particle **p,
  const int start,               // start of particle block in array
  const int end,                 // end of particle block in array
  const int median,              // desired median number
  const int axis )               // axis to split along
//*****************************************************************
{
#define swap(ph,a,b) { Particle *ph2=ph[a]; ph[a]=ph[b]; ph[b]=ph2; }
  int left = start;
  int right = end;

  while ( right > left ) {
    const float v = p[right]->pos[axis];
    int i=left-1;
    int j=right;
    for (;;) {
      while ( p[++i]->pos[axis] < v )
        ;
      while ( p[--j]->pos[axis] > v && j>left )
        ;
      if ( i >= j )
        break;
      swap(p,i,j);
    }

    swap(p,i,right);
    if ( i >= median )
      right=i-1;
    if ( i <= median )
      left=i+1;
  }
}


// See "Realistic image synthesis using Particle Mapping" chapter 6
// for an explanation of this function
//****************************
static void balance_segment(
  ParticleMap *map,
  Particle **pbal,
  Particle **porg,
  const int index,
  const int start,
  const int end )
//****************************
{

  //--------------------
  // compute new median
  //--------------------
  int axis;
  int median=1;

  while ((4*median) <= (end-start+1))
    median += median;

  if ((3*median) <= (end-start+1)) {
    median += median;
    median += start-1;
  } else	
    median = end-median+1;

  //--------------------------
  // find axis to split along
  //--------------------------

  axis=2;
  if ((map->bbox_max[0]-map->bbox_min[0])>(map->bbox_max[1]-map->bbox_min[1]) &&
      (map->bbox_max[0]-map->bbox_min[0])>(map->bbox_max[2]-map->bbox_min[2]))
    axis=0;
  else if ((map->bbox_max[1]-map->bbox_min[1])>(map->bbox_max[2]-map->bbox_min[2]))
    axis=1;

  //------------------------------------------
  // partition particle block around the median
  //------------------------------------------

  median_split( porg, start, end, median, axis );

  pbal[ index ] = porg[ median ];
  pbal[ index ]->plane = axis;

  //----------------------------------------------
  // recursively balance the left and right block
  //----------------------------------------------

  if ( median > start ) {
    // balance left segment
    if ( start < median-1 ) {
      const float tmp=map->bbox_max[axis];
      map->bbox_max[axis] = pbal[index]->pos[axis];
      balance_segment( map,pbal, porg, 2*index, start, median-1 );
      map->bbox_max[axis] = tmp;
    } else {
      pbal[ 2*index ] = porg[start];
    }
  }

  if ( median < end ) {
    // balance right segment
    if ( median+1 < end ) {
      const float tmp = map->bbox_min[axis];		
      map->bbox_min[axis] = pbal[index]->pos[axis];
      balance_segment(map, pbal, porg, 2*index+1, median+1, end );
      map->bbox_min[axis] = tmp;
    } else {
      pbal[ 2*index+1 ] = porg[end];
    }
  }	
}

/* balance creates a left balanced kd-tree from the flat particle array.
 * This function should be called before the particle map
 * is used for rendering.
 */
//******************************
BalancedParticleMap * balanceParticleMap(ParticleMap *map)
//******************************
{
  BalancedParticleMap *bmap;
  if (map->stored_particles>1) {
    int i;
	int d,j,foo;
	Particle foo_particle;
    // allocate two temporary arrays for the balancing procedure
    Particle **pa1 = (Particle**)malloc(sizeof(Particle*)*(map->stored_particles+1));
    Particle **pa2 = (Particle**)malloc(sizeof(Particle*)*(map->stored_particles+1));

    for (i=0; i<=map->stored_particles; i++)
      pa2[i] = &map->particles[i];

    balance_segment(map, pa1, pa2, 1, 1, map->stored_particles );
    free(pa2);

    // reorganize balanced kd-tree (make a heap)
    j=1;
	foo=1;
    foo_particle = map->particles[j];

    for (i=1; i<=map->stored_particles; i++) {
      d=pa1[j]-map->particles;
      pa1[j] = NULL;
      if (d != foo)
        map->particles[j] = map->particles[d];
      else {
        map->particles[j] = foo_particle;

        if (i<map->stored_particles) {
          for (;foo<=map->stored_particles; foo++)
            if (pa1[foo] != NULL)
              break;
          foo_particle = map->particles[foo];
          j = foo;
        }
        continue;
      }
      j = d;
    }
    free(pa1);
  }

 bmap=malloc(sizeof(BalancedParticleMap));
 bmap->stored_particles      = map->stored_particles;
 bmap->half_stored_particles = map->stored_particles/2-1;
 bmap->particles=map->particles;
 free(map);
 return (BalancedParticleMap*) bmap;
}



/* locate_particles finds the nearest particles in the
 * particle map given the parameters in np
*/
//******************************************
void locateParticles(
	BalancedParticleMap *map,
  NearestParticles *const np,
  const int index)
//******************************************
{
  const Particle *p = &map->particles[index];
  float dist1;
  float dist2;

  if (index<map->half_stored_particles) {
    dist1 = np->pos[ p->plane ] - p->pos[ p->plane ];

    if (dist1>0.0) { // if dist1 is positive search right plane
      locateParticles( map,np, 2*index+1 );
      if ( dist1*dist1 < np->dist2[0] )
        locateParticles(map,np, 2*index );
    } else {         // dist1 is negative search left first
      locateParticles(map,np, 2*index );
      if ( dist1*dist1 < np->dist2[0] )
        locateParticles(map,np, 2*index+1 );
    }
  }

  // compute squared distance between current particle and np->pos

  dist1 = p->pos[0] - np->pos[0];
  dist2 = dist1*dist1;
  dist1 = p->pos[1] - np->pos[1];
  dist2 += dist1*dist1;
  dist1 = p->pos[2] - np->pos[2];
  dist2 += dist1*dist1;
  
  if ( dist2 < np->dist2[0] ) {
    // we found a particle :) Insert it in the candidate list
    if ( np->found < np->max ) {
      // heap is not full; use array
      np->found++;
      np->dist2[np->found] = dist2;
      np->index[np->found] = p;
    } 
    else {
      int j,parent;
      
      if (np->got_heap==0) { // Do we need to build the heap?
        // Build heap
        float dst2;
		int k;
        const Particle *phot;
        int half_found = np->found>>1;
        for ( k=half_found; k>=1; k--) {
          parent=k;
          phot = np->index[k];
          dst2 = np->dist2[k];
          while ( parent <= half_found ) {
            j = parent+parent;
            if (j<np->found && np->dist2[j]<np->dist2[j+1])
              j++;
            if (dst2>=np->dist2[j])
              break;
            np->dist2[parent] = np->dist2[j];
            np->index[parent] = np->index[j];
            parent=j;
          }
          np->dist2[parent] = dst2;
          np->index[parent] = phot;
        }
        np->got_heap = 1;
      }

      // insert new particle into max heap
      // delete largest element, insert new and reorder the heap

      parent=1;
      j = 2;
      while ( j <= np->found ) {
        if ( j < np->found && np->dist2[j] < np->dist2[j+1] )
          j++;
        if ( dist2 > np->dist2[j] )
          break;
        np->dist2[parent] = np->dist2[j];
        np->index[parent] = np->index[j];
        parent = j;
        j += j;
      }
      np->index[parent] = p;
      np->dist2[parent] = dist2;

      np->dist2[0] = np->dist2[1];
    }
  }
}

/* irradiance_estimate computes an irradiance estimate
 * at a given surface position
*/
//**********************************************
float densityEstimate(
  BalancedParticleMap *map,
  const float pos[3],            // surface position
  const float max_dist,          // max distance to look for particles
  const int nparticles )     // number of particles to use
//**********************************************
{
  NearestParticles np;
  float pdir[3];
  float r;
  int i;
  
  np.dist2 = (float*)alloca( sizeof(float)*(nparticles+1) );
  np.index = (const Particle**)alloca( sizeof(Particle*)*(nparticles+1) );

  np.pos[0] = pos[0]; np.pos[1] = pos[1]; np.pos[2] = pos[2];
  np.max = nparticles;
  np.found = 0;
  np.got_heap = 0;
  np.dist2[0] = max_dist*max_dist;

  // locate the nearest particles
  locateParticles( map,&np, 1 );
  //printf("Found %d particles\n",np.found);
  // if less than 8 particles return
  if (np.found==0)
    return 0;


  {
  const float volume=4.0/3.0*M_PI*pow(np.dist2[0],3.0/2.0);  // estimate of density
  return ((float)np.found)/volume;
  }
}

void saveParticleMap(BalancedParticleMap *bmap,char *filename)
	{
	FILE *fp=fopen(filename,"wb");
	fwrite(bmap->particles,sizeof(Particle),bmap->stored_particles,fp);
	fclose(fp);
	}

BalancedParticleMap * loadParticleMap(char *filename)
	{
	struct stat sbuf;
	int count;
	FILE *fp;
	BalancedParticleMap *bmap;
	fp=fopen(filename,"rb");
	assert(fp);

	bmap=malloc(sizeof(BalancedParticleMap));
#if 1
	/* PRMan has a problem with calling stat() in DSO's
	   on Linux (and I'm assuming you're on Linux! cause
	   the MacOSX version isn't out yet...)
           The nice guys at Pixar figured out that
	   if you call __xstat() it works!
	   It's a GCC thing.
	   If this causes you problems try changing it back to stat
	   Alternativly there's a work around version in the other half
	   of this #if
	   */
	__xstat(_STAT_VER,filename,&sbuf);
	bmap->stored_particles=sbuf.st_size/sizeof(Particle);
	bmap->particles=malloc(sbuf.st_size);
	if (bmap->particles == NULL)
		  {
		  fprintf(stderr,"Out of memory initializing particle map\n");
		  exit(-1);
		  }
	count= fread(bmap->particles,sizeof(Particle),bmap->stored_particles,fp);
    assert(count==bmap->stored_particles);
#else
	//If your renderer has a problem with stat then
	//you can try to use this dumb version...
	//Unfortunatly it only loads 100000 particles.
	bmap->particles=malloc(100000*sizeof(Particle));
	bmap->stored_particles=fread(bmap->particles,sizeof(Particle),100000,fp);
#endif
	fclose(fp);
	bmap->half_stored_particles = bmap->stored_particles/2-1;

	return bmap;
	}
