#ifndef PARTICLEMAP_H
#define PARTICLEMAP_H


/* This is the particle
 * The power is not compressed so the
 * size is 28 bytes
*/
//**********************
typedef struct Particle {
//**********************
  float pos[3];                 // particle position
  short plane;                  // splitting plane for kd-tree
} Particle;


/* This structure is used only to locate the
 * nearest particles
*/
//******************************
typedef struct NearestParticles {
//******************************
  int max;
  int found;
  int got_heap;
  float pos[3];
  float *dist2;
  const Particle **index;
} NearestParticles;

typedef struct BalancedParticleMap{
//******************************
  int stored_particles;
  Particle *particles;
  int half_stored_particles;
} BalancedParticleMap;


/* This is the biggy,
 * The actual particle map structure
 */
//******************************
typedef struct ParticleMap{
//******************************
  int stored_particles;
  Particle *particles;
  int half_stored_particles;

  int max_particles;
  float bbox_min[3];		// use bbox_min;
  float bbox_max[3];		// use bbox_max;
} ParticleMap;

ParticleMap *createParticleMap(int max_particles);
void storeParticle(ParticleMap *map,
    const float pos[3]);            // particle position


BalancedParticleMap *balanceParticleMap(ParticleMap *map);  // balance the kd-tree

void saveParticleMap(BalancedParticleMap *bmap,char *filename);
BalancedParticleMap * loadParticleMap(char *filename);

void locateParticles(
	BalancedParticleMap *map,
    NearestParticles *const np,      // np is used to locate the particles
    const int index );       // call with index = 1

float densityEstimate(
  BalancedParticleMap *map,
  const float pos[3],            // surface position
  const float max_dist,          // max distance to look for particles
  const int nparticles );     // number of particles to use

void destroyParticleMap(BalancedParticleMap *map);

#endif // PARTICLEMAP_H
