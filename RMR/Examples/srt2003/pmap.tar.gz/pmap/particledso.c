#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include <sys/stat.h>
#include "shadeop.h"

#ifndef WIN32
#include <alloca.h>
#endif

#include "particlemap.h"

static BalancedParticleMap *theMap=NULL;

SHADEOP_TABLE(initparticlemap) =
     {
             { "void initparticlemap (string)", "", "" },
             { "" }
     };
SHADEOP_TABLE(particlemap) =
     {
             { "float particlemap (point,float,float)", "", "" },
             { "" }
     };

SHADEOP(initparticlemap)
{
	STRING_DESC *arg=(STRING_DESC *)argv[1];
	static char *cached=NULL;
	if(cached && strcmp(arg->s,cached)!=0)
		{
		destroyParticleMap(theMap);
		theMap=NULL;
		free(cached);
		cached=NULL;
		}
	if(theMap==NULL) 
		{
		theMap=loadParticleMap(arg->s);
		cached=malloc(strlen(arg->s)+1);
		strcpy(cached,arg->s);
		printf ("loaded %d particles from %s\n",theMap->stored_particles,cached);
		}
	//*(float *)argv[0]=0;
	return 0;
}



SHADEOP(particlemap)
{
	float *pos=(float *)argv[1];
	float radius=*(float *)argv[2];
	int count=*(float *)argv[3];

	*(float *)argv[0]=densityEstimate(theMap,pos,radius,count);
	//if( *(float *)argv[0]>0)
	//	printf("%f %f %f=%f\n",pos[0],pos[1],pos[2], *(float *)argv[0]);

	return 0;
}
