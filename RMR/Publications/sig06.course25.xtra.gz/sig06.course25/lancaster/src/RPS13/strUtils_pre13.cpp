/*
 * Walt Disney Feature Animation
 * Tal Lancaster
 *
 * strreplace.cpp
 *
 *  RenderMan DSO to look for a pattern in a string and to build up a
 *  new string -- ie. string replacement.
 *
 *   strreplace (src, pattern, subst)
 *   strreplace ("rmantex/@ELEM.color.tx", "@ELEM", "myElem")
 *      == "rmantex/myElem.color.tx"
 */

#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <pcrecpp.h>
#include <stdio.h>

#include <iostream>
#include <string>

#include <shadeop.h>

SHADEOP_TABLE(strreplace) =
{
  {"string strreplace (string, string, string)", "" /* init*/, "" /* cleanup*/},
  {""}
};


extern "C"
SHADEOP (strreplace) {
    char del = ':';

    if (argc != 4) return 1;

    STRING_DESC* result = (STRING_DESC*)(argv[0]);
    STRING_DESC* rm_src = (STRING_DESC*)(argv[1]);
    STRING_DESC* rm_pattern = (STRING_DESC*)(argv[2]);
    STRING_DESC* rm_replacement = (STRING_DESC*)(argv[3]);

    bool isfound;
    std::string newstr;

#ifdef STRING_CACHE
    std::string key = 
	std::string(rm_src->s) + del + rm_pattern->s + del + 
	rm_replacement->s;

    char*& val = LookupStrCache((char*)(key.c_str()), isfound);
    if (!isfound) {
	newstr = rm_src->s;
	pcrecpp::RE(rm_pattern->s).GlobalReplace(rm_replacement->s, &newstr);

	val = strdup (newstr.c_str());
    }
    result->s = val;
#else
    newstr = rm_src->s;
    pcrecpp::RE(rm_pattern->s).GlobalReplace(rm_replacement->s, &newstr);

    result->s = strdup (newstr.c_str());
#endif // STRING_CACHE    
    return 0;
}


/* str_reframeMap ()
 *
 * Assuming pattern baseName.%04d.tx replacing the 4 digit padded
 * frame number with the number that is passed in.  If the string 
 * doesn't contain a 4 padded number the original string is passed back.
 *
 */

SHADEOP_TABLE(str_reframeMap) =
{
  {"string str_reframeMap (string, float)", "" /* init*/, "" /* cleanup*/},
  {""}
};


extern "C"
SHADEOP (str_reframeMap) {
    if (argc != 3) return 1;

    STRING_DESC* result = (STRING_DESC*)(argv[0]);
    STRING_DESC* rm_src = (STRING_DESC*)(argv[1]);
    float rm_frame = * ( (float*) argv[2]);

    bool isfound;
    char del = ':';
    std::string newstr;
    std::string pattern = "\\.\\d\\d\\d\\d\\.";

    int iframe = (int) rm_frame;
    char cframe[7];

    sprintf (cframe, ".%04d.", iframe);
   
#ifdef STRING_CACHE
    std::string key =
	std::string (rm_src->s) + del + pattern + del + cframe;

    char*& val = LookupStrCache((char*)(key.c_str()), isfound);
    if (!isfound) {
	newstr = rm_src->s;

	pcrecpp::RE(pattern).Replace(cframe, &newstr);

	val = strdup (newstr.c_str());
    }
    result->s = val;
#else
    newstr = rm_src->s;
    pcrecpp::RE(pattern).Replace(cframe, &newstr);
    result->s = strdup (newstr.c_str());
#endif // STRING_CACHE    
    return 0;
}



