#include "shadeop.h"

SHADEOP_TABLE(sqr) =
{
        { "float sqr_f (float)", "", "" },
        { "point sqr_triple (point)", "", "" },
        { "vector sqr_triple (vector)", "", "" },
        { "normal sqr_triple (normal)", "", "" },
        { "color sqr_triple (color)", "", "" },
        { "" }
};

SHADEOP (sqr_f)
{
        float *result = (float *)argv[0];
        float *x = (float *)argv[1];
        *result = (*x) * (*x);
        return 0;
}

SHADEOP (sqr_triple)
{
        int i;
        float *result = (float *)argv[0];
        float *x = (float *)argv[1];
        for (i = 0; i < 3; ++i, ++result, ++x)
        {
                *result = (*x) * (*x);
        }
        return 0;
}
