/*
 * Walt Disney Feature Animation
 * Tal Lancater
 * 4/11/06
 *
 *  RenderMan DSO to look for a pattern in a string and to build up a
 *  new string -- ie. string replacement.
 *
 *   strreplace (src, pattern, subst)
 *   strreplace ("rmantex/@ELEM.color.tx", "@ELEM", "myElem")
 *      == "rmantex/myElem.color.tx"
 */

#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <pcrecpp.h>
#include <stdio.h>
#include <rx.h>

#include <iostream>
#include <string>

#include <D_RslPlugin.h>

extern "C" {

RSLFUNC (strreplace, "string strreplace (string, string, string)")
{
    char del = ':';

    if (argc != 4) return 1;

    STRING_ARG(result, 0);
    STRING_ARG(rm_src, 1);
    STRING_ARG(rm_pattern, 2);
    STRING_ARG(rm_replacement, 3);

    std::string newstr;

    int numVals = argv[0]->NumValues();

    for (int i = 0; i < numVals; ++i) {
	bool isfound = 0;

#ifdef STRING_CACHE
	std::string key = 
	    std::string(*rm_src) + del + *rm_pattern + del + 
	    *rm_replacement;

	char*& val = LookupStrCache((char*)(key.c_str()), isfound);
#endif // STRING_CACHE

	if (!isfound) {
	    newstr = *rm_src;
	    pcrecpp::RE(*rm_pattern).GlobalReplace(*rm_replacement, &newstr);

#ifdef STRING_CACHE
	    val = strdup (newstr.c_str());
#else
	    *result = strdup (newstr.c_str());
#endif
	}

#ifdef STRING_CACHE
	*result = val;
#endif
    
	++result; ++rm_src; ++rm_pattern; ++rm_replacement;
    }
    return 0;
}

/* str_reframeMap ()
 *
 * Assuming pattern baseName.%04d.tx replacing the 4 digit padded
 * frame number with the number that is passed in.  If the string 
 * doesn't contain a 4 padded number the original string is passed in.
 *
 */
RSLFUNC (str_reframeMap, "string str_reframeMap (string, float)") 
{
    if (argc != 3) return 1;

    STRING_ARG(result, 0);
    STRING_ARG(rm_src, 1);
    STRING_ARG(rm_frame, 2);

    char del = ':';
    std::string newstr;
    std::string pattern = "\\.\\d\\d\\d\\d\\.";

    int numVals = argv[0]->NumValues();
    for (int i = 0; i < numVals; i++) {

	bool isfound = 0;

	char cframe[7];

	sprintf (cframe, ".%04d.", *rm_frame);
   
	//printf ("cframe %s\n", cframe);

#ifdef STRING_CACHE
	std::string key =
	    std::string (*rm_src) + del + pattern + del + cframe;

	char*& val = LookupStrCache((char*)(key.c_str()), isfound);
#endif

	if (!isfound) {
	    newstr = *rm_src;
	    
	    pcrecpp::RE(pattern).Replace(cframe, &newstr);

#ifdef STRING_CACHE
	    val = strdup (newstr.c_str());
#else
	    *result = strdup (newstr.c_str());
#endif
	}
#ifdef STRING_CACHE
	*result = val;
#endif
	++result; ++rm_src; ++rm_frame;
    }
    return 0;
}

} // extern "C"
