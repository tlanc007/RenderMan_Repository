/* 
 *
 * PRMan-13 timer shadeop
 *
 * Walt Disney Feature Animation
 * Brent Burley
 *
 * Converted over for prman-13 Tal Lancaster 4/11/06
 *
 */

#include <rx.h>
#include <sys/time.h>
#include <string>
#include <map>
#include <vector>
#include <algorithm>
#include <stdio.h>

#include <D_RslPlugin.h>

namespace {
    inline void rdtsc(unsigned long long& ts) {
	__asm__ __volatile__ ("rdtsc" : "=A" (ts)); 
    }

    class timer {
	unsigned long long ts1, ts2, total, overhead, count;
    public:
	inline void start() { rdtsc(ts1); count++; }
	inline void stop() { rdtsc(ts2); total += ts2-ts1 - overhead; }

	timer() : total(0), overhead(0), count(0)
	{
	    static bool calibrated = 0;
	    static unsigned long long _overhead = 0;
	    if (!calibrated) {
		calibrated = 1;
		for (int i = 0; i < 10; i++) { start(); stop(); }
		_overhead = total/10; total=0;
	    }
	    overhead = _overhead;
	}

	unsigned long long gettotal() { return total; }
	unsigned long long getcount() { return count; }
    };

    typedef std::map<std::string, timer> TimerMap;

    struct TimerSort {
	bool operator()(const TimerMap::iterator& a, const TimerMap::iterator& b) 
	{ return a->second.gettotal() > b->second.gettotal(); }
    };

    TimerMap* timers = new TimerMap;
    
    timer& GetTimer(const char* name)
    {
	return (*timers)[name];
    }

    struct PrintStats
    {
	unsigned long long starttics;
	double startsecs;

	PrintStats() {
	    rdtsc(starttics);
	    struct timeval tv; gettimeofday(&tv, 0);
	    startsecs = tv.tv_sec + 1e-6 * tv.tv_usec;
	}

	~PrintStats()
	{
	    unsigned long long stoptics; rdtsc(stoptics);
	    struct timeval tv; gettimeofday(&tv, 0);
	    double stopsecs = tv.tv_sec + 1e-6 * tv.tv_usec;
	    double totalSecs = (stopsecs - startsecs);
	    double secsPerTick = totalSecs / (stoptics - starttics);

	    std::vector<TimerMap::iterator> sorted;
	    for (TimerMap::iterator i = timers->begin(); i != timers->end(); i++)
	    {
		sorted.push_back(i);
	    }
	    if (sorted.empty()) return;
	    std::sort(sorted.begin(), sorted.end(), TimerSort());
	    // print entries more than 1% (or at least 10 entries)
	    double threshhold = std::min(totalSecs / 100, 
					 sorted[std::min(9, int(sorted.size()-1))]
					 ->second.gettotal() * secsPerTick);
	    printf("%-37s %-16s %s\n", "Timer Name", " Seconds ( pct )", "     Count");
	    
	    std::vector<TimerMap::iterator>::iterator iter;
	    for (iter = sorted.begin(); iter != sorted.end(); iter++) {
		const char* name = (*iter)->first.c_str();
		double secs = (*iter)->second.gettotal() * secsPerTick;
		unsigned long long count = (*iter)->second.getcount();
		double percent = secs / totalSecs * 100;
		if (secs >= threshhold)
		    printf("  %-35s %8.2f (%4.1f%%) %10.10g\n",
			   name, secs, percent, double(count));
	    }
	    fflush (stdout);
	}
    } printstats;
}

static bool useTimer = 0;

pthread_mutex_t mutex_timerShadeop = PTHREAD_MUTEX_INITIALIZER;

extern "C" {

RSLFUNC (timerStart, "float timerStart(string)")
{
    static bool initialized = 0;

    // locking everything for now. Maybe can get better granularity
    pthread_mutex_lock (&mutex_timerShadeop);

    if (!initialized) {
	initialized = 1;
	int option=0, count=0;
	RxInfoType_t type;
	if (RxOption("user:usetimer", &option, sizeof(option), &type, &count) == 0 &&
	    type == RxInfoInteger && count == 1 && option > 0) useTimer = 1;
	const char* env = getenv("USE_SHADER_TIMER");
	if (env) { useTimer = (strcmp(env, "0") != 0); }
	if (useTimer) {
	    printf("Profiling timer enabled. "
		   "Statistics will be printed at end of render.\n");
	    //fflush (NULL);
	}
    }
    if (!useTimer) {
	pthread_mutex_unlock (&mutex_timerShadeop);
	return 0;
    }
    if (argc != 2) {
	pthread_mutex_unlock (&mutex_timerShadeop);
	return 1;
    }

    RslFloatIter  result (argv[0]);
    RslStringIter timerName (argv[1]);

    int numVals = argv[0]->NumValues();

    for (int i = 0; i < numVals; ++i) {
	GetTimer(*timerName).start();

	// not really returning anything
	++result;
	++timerName;
    }
    pthread_mutex_unlock (&mutex_timerShadeop);

    return 0;     
}

RSLFUNC (timerStop, "float timerStop(string)") 
{
    if (!useTimer)
	return 0;

    if (argc != 2)
	return 1;

    FLOAT_ARG(result, 0);
    STRING_ARG(timerName, 1);

    int numVals = argv[0]->NumValues();

    pthread_mutex_lock (&mutex_timerShadeop);

    for (int i = 0; i < numVals; ++i) {
	GetTimer(*timerName).stop();
	++result; ++timerName;
    }

    pthread_mutex_unlock (&mutex_timerShadeop);

    return 0;
}

} // extern "C"
