/*
 * Set up file for all Disney Rsl Plugins.
 *
 * $Id: D_RslPlugin.h,v 3.2 2006/05/24 16:47:29 tlan Exp $
 *
 */

#ifndef D_RSLPLUGIN_H
#define D_RSLPLUGIN_H

#include <pthread.h>
#include <RslPlugin.h>

/* shadeops, also has data for symbol table */
#define RSLFUNC(name, proto) RSLEXPORT int name(RslContext* rslContext, int argc, const RslArg* argv[])

/* shadeops, also has data for symbol table.  
   In this case init & cleanup sections */
#define RSLFUNC_IC(name, init, cleanup, proto) RSLEXPORT int name(RslContext* rslContext, int argc, const RslArg* argv[])

/* For cases where RSL is sharing the same dso function call.  
   Need data for symbol table*/
#define RSLFUNC_DUMMY(name,  proto)
#define RSLFUNC_IC_DUMMY(name, init, cleanup, proto)

/* Iterator macros to set local variables inside the shadeop */
#define FLOAT_ARG(name, n) RslFloatIter name (argv[n])
#define STRING_ARG(name, n) RslStringIter name (argv[n])
#define POINT_ARG(name, n) RslPointIter name (argv[n])
#define COLOR_ARG(name, n) RslColorIter name (argv[n])


#endif // D_RSLPLUGIN_H
