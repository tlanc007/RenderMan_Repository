/*
 * Tal Lancaster
 * April 11, 2006
 *
 * PRMan-13 shadeop example sqrt
 */

#include "stdio.h"

#include <D_RslPlugin.h>

extern "C" {

RSLFUNC (sqr_f, "float sqr (float)")
int argc, const RslArg* argv[])
{
    FLOAT_ARG(result, 0);
    FLOAT_ARG(x, 1);
    
    int numVals = argv[0]->NumValues();
    
    // run through all of the active shading points
    for (int i = 0; i < numVals; ++i) {
	*result = *x * *x;
	++result; ++x;
    }
    return 0;
}

RSLFUNC_DUMMY(sqr_triple, "vector sqr (vector)")
RSLFUNC_DUMMY(sqr_triple, "normal sqr (normal)")
RSLFUNC_DUMMY(sqr_triple, "color sqr (color)")

RSLFUNC (sqr_triple,  "point sqr (point)")
{
    POINT_ARG(result, 0);  // points, normals, colors float[3]
    POINT_ARG(x, 1);

    int numVals = argv[0]->NumValues();
    for (int i = 0; i < numVals; ++i) {
      
	(*result)[0] = (*x)[0] * (*x)[0];
	(*result)[1] = (*x)[1] * (*x)[1];
	(*result)[2] = (*x)[2] * (*x)[2];
        
	++result; ++x;
    }
    return 0;
}

} // extern "C"
