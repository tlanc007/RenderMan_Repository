/*
 * Tal Lancaster
 * April 11, 2006
 *
 * PRMan-13 shadeop example sqrt
 */

#include "stdio.h"

#include "RslPlugin.h"

extern "C" {

RSLEXPORT int sqr_f (RslContext* rslContext,
int argc, const RslArg* argv[])
{
    RslFloatIter result (argv[0]);
    RslFloatIter x (argv[1]);
    
    int numVals = argv[0]->NumValues();
    
    // run through all of the active shading points
    for (int i = 0; i < numVals; ++i) {
	*result = *x * *x;
	++result; ++x;
    }
    return 0;
}

RSLEXPORT int sqr_triple (RslContext* rslContext,
			  int argc, const RslArg* argv[])
{
    RslPointIter result (argv[0]);  // points, normals, colors float[3]
    RslPointIter x (argv[1]);

    int numVals = argv[0]->NumValues();
    for (int i = 0; i < numVals; ++i) {
      
	(*result)[0] = (*x)[0] * (*x)[0];
	(*result)[1] = (*x)[1] * (*x)[1];
	(*result)[2] = (*x)[2] * (*x)[2];
        
	++result; ++x;
    }
    return 0;
}

static RslFunction shadeops[] =
{
    { "float sqr (float)", sqr_f},
    { "point sqr (point)", sqr_triple},
    { "vector sqr (vector)", sqr_triple},
    { "normal sqr (normal)", sqr_triple},
    { "color sqr (color)", sqr_triple},
    NULL
};

    RSLEXPORT RslFunctionTable RslPublicFunctions = shadeops;
} // extern "C"
