#ifndef HELPERS_H
#define HELPERS_H 1
/* Superellipse soft clipping -- straight from uberlight
 * Input:
 *   - point Q on the x-y plane
 *   - the equations of two superellipses (with major/minor axes given by
 *        a,b and A,B for the inner and outer ellipses, respectively)
 * Return value:
 *   - 0 if Q was inside the inner ellipse
 *   - 1 if Q was outside the outer ellipse
 *   - smoothly varying from 0 to 1 in between
 */
float clipSuperellipse(
		float x, y;          /* Test point on the x-y plane */
		float a, b;       /* Inner superellipse */
		float A, B;       /* Outer superellipse */
		float roundness;  /* Same roundness for both ellipses */
) {
	float result = 0;
	if(x != 0 || y != 0) {  /* avoid degenerate case */
		if(roundness < 1.0e-6) {
			/* Simpler case of a square */
			result = 1 - (1 - smoothstep(a, A, x)) * (1 - smoothstep(b, B, y));
		} else if(roundness > 0.9999) {
			/* Simple case of a circle */
			float sqr(float x) { return x * x; }
			float q = a * b / sqrt(sqr(b * x) + sqr(a * y));
			float r = A * B / sqrt(sqr(B * x) + sqr(A * y));
			result = smoothstep(q, r, 1);
		} else {
			/* Harder, rounded corner case */
			float re = 2 / roundness;   /* roundness exponent */
			float q = a * b * pow(pow(b * x, re) + pow(a * y, re), -1 / re);
			float r = A * B * pow(pow(B * x, re) + pow(A * y, re), -1 / re);
			result = smoothstep(q, r, 1);
		}
	}
	return result;
}

/* 'Linear' version of smoothstep() */
#define linearStep(a,b,x) clamp(((x) - (a)) / ((b) - (a)), 0, 1)

/* Normalized polar coordinates */
#define normalizedPolar(x, y, r, theta) \
	r = sqrt((x) * (x) + (y) * (y)); \
	theta = (atan(y, x) + PI) / (2 * PI);

/* Ken Perlin's smoothstep replacememt from Texturing & Modeling, 2nd ed.
 * y = 6 * X^5 + 15 * x^4 + 10 * x^3
 * Unlike smoothstep(), is has zero 1st and 2nd order derivatives at x=0 and x=1
 * For anything geometry related (e,g. in a displacement shader), this gives us
 * a nicer shading than if using smoothstep()
 * Input/Return value:
 *   like smoothstep()
 */
float smootherstep(float min, max, value;) {
	float x = clamp((value - min) / (max - min), 0, 1);
	return x * x * x * (x * (x * 6 - 15) + 10);
}


/* Number of channel present in a texture file.
 * Input:
 *   - texturename
 * Return value:
 *   - 0 if the given texturename was empty or the texture doesn't exist.
 *   - number of channels otherwise
 */
float numTextureChannels(uniform string texturename) {
	uniform float channels = 0;
	if("" != texturename) {
		textureinfo(texturename, "channels", channels);
	}
	return channels;
}

/* Remap a coordinate so it's new origin lies at 0.5 * scale, then scale by scale
 * Optionally flip the sign before.
 * Input:
 *   - original coordinate in a
 *   - scale to apply
 *   - flip sign
 * Return value:
 *   - remapped coordinate
 */
float remapCoordinate(varying float a; uniform float scale; uniform float flip) {
	float result = a;
	if(0 != flip) {
		result *= -1;
	}
	result = (result + 0.5 * scale) / scale;
	return result;
}

/* Color from a texture map.
 * Does the right thing(tm) depending on the number of channels found in a texture:
 *   1 - use channel 1 for grayscale mapOpacity -- mapColor is untouched
 *   2 - same as 2, channel 2 is ignored
 *   3 - use channels 1-3 for mapColor
 *   4 or more - same as 3, channels 4+ are ignored
 * Input:
 *   - texturename
 *   - texture coordinates in ss and tt
 *   - variable for color return value in mapColor
 * Output:
 *   - mapColor, modified if texture exists
 * Return value:
 *   - mapColor, modified if texture exists
 */
color getColor(uniform string texturename; varying float ss, tt; output varying color mapColor) {
	uniform float channels = numTextureChannels(texturename);
	if(0 < channels) {
		/* If we have 1 or 2 channels... */
		if(3 > channels) {
			/* Make r,g,b get the value from channel 0 */
			mapColor = float texture(texturename[ 0 ], ss, tt);
		/* If we have 3 or more channels... */
		} else {
			mapColor = texture(texturename, ss, tt);
		}
	/* Do nothing if the map is empty */
	}
	return mapColor;
}

/* Greyscale from a texture map.
 * Does the right thing(tm) depending on the number of channels found in a texture:
 *   1 - use channel 1
 *   2 - same as 2, channel 2 is ignored
 *   3 - convert color to luminance
 *   4 or more - same as 3, channels 4+ are ignored
 * Input:
 *   - texturename
 *   - texture coordinates in ss and tt
 *   - variable for grey return value in mapColor
 * Output:
 *   - mapGrey, modified if texture exists
 * Return value:
 *   - mapGrey, modified if texture exists
 */
color getGrey(uniform string texturename; varying float ss, tt; output varying float mapGrey) {
	uniform float channels = numTextureChannels(texturename);
	if(0 < channels) {
		/* If we have 1 or 2 channels... */
		if(3 > channels) {
			/* Make r,g,b get the value from channel 0 */
			mapGrey = float texture(texturename[ 0 ], ss, tt);
		/* If we have 3 or more channels... */
		} else {
			/* convert color to 'greyscale', using CIE Luminance */
			color Ctmp = texture(texturename, ss, tt);
			mapGrey = 0.2126 * comp(Ctmp, 0) + 0.7152 * comp(Ctmp, 1) + 0.0722 * comp(Ctmp, 2);
		}
	/* Do nothing if the map is empty */
	}
	return mapGrey;
}

/* Color and opacity from a texture map.
 * Does the right thing(tm) depending on the number of channels found in a texture:
 *   1 - use channel 1 for grayscale mapOpacity -- mapColor is untouched
 *   2 - use channel 1 for grayscale mapColor and channel 2 for grayscale mapOpacity
 *   3 - use channels 1-3 for mapColor
 *   4 - use channels 1-3 for mapColor + channel 4 for grayscale mapOpacity
 *   5 - same as 4, channel 5 is ignored
 *   6 - use channels 1-3 for mapColor + channels 4-6 for mapOpacity
 *   7 or more - same as 6, channels 7+ are ignored
 * Input:
 *   - texturename
 *   - texture coordinates in ss and tt
 *   - variable for color return value in mapColor
 * Output:
 *   - mapColor, modified if texture exists
 *   - mapOpacity, modified if texture exists
 * Return value"
 *   - mapColor, modified if texture exists
 */
color getColorAndOpacity(uniform string texturename; varying float ss, tt; output varying color mapColor, mapOpacity) {
	uniform float channels = numTextureChannels(texturename);
	if(0 < channels) {
		/* If we have 1 or 2 channels... */
		if(3 > channels) {
			/* Make r,g,b get the value from channel 0 */
			varying float tmp = float texture(texturename[ 0 ], ss, tt);
			/* If this texture has an alpha, use it... */
			if(2 == channels) {
				mapColor = tmp;
				mapOpacity = float texture(texturename[ 1 ], ss, tt);
			/* If it doesn't, it's a one-channel map -- use it as the alpha for our Color... */
			} else {
				mapOpacity = tmp;
				/* pre-multiply input color */
				mapColor *= mapOpacity;
			}
		/* If we have 3 or 4 channels... */
		} else {
			mapColor = texture(texturename, ss, tt);
			/* If this texture has at least 3 more channels use those as opacity... */
			if(5 < channels) {
				mapOpacity = color(float texture(texturename[ 3 ], ss, tt),
									float texture(texturename[ 4 ], ss, tt),
									float texture(texturename[ 5 ], ss, tt));
			/* Otherwise if we have at least a 4th channel us that as alpha... */
			} else if(3 < channels) {
				mapOpacity = float texture(texturename[ 3 ], ss, tt);
			/* If we only have three channels use a solid alpha */
			} else {
				mapOpacity = 1;
			}
		}
	/* Do nothing if the map is empty */
	}
	return mapColor;
}
