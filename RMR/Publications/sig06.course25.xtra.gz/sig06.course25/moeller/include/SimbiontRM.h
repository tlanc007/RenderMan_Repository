/*$Id: SimbiontRM.h,v 1.2 2003/05/15 16:56:30 august Exp $*/

/*sc****************************************************************************
--------------------------------------------------------------------------------
    Name: SimbiontRM.h
--------------------------------------------------------------------------------

    Description: Some helpful stuff for using the SimbiontRM DSO shadops.

    NOTE - the point P is added to the argument list of SimRM_GetContextID()
     to get around a 3Delight optimization.  It seems to assume that if a DSO
     function has a constant argument, it has a constant return value as well.

    Revision History:
        Rev.001 05/14/03 (AAS) - Initial version.

**ec***************************************************************************/

/*Filter width calculation.*/
/*-------------------------*/
#ifndef filterwidth

#define MINFILTERWIDTH  0.00001
#define filterwidth(p)  max(abs(Du(p))*du+abs(Dv(p)*dv), MINFILTERWIDTH)
#define filterwidthp(p) max(sqrt(area(p)), MINFILTERWIDTH)

#endif

/*Evaluation type enumerations.          */
/*Note - these must exactly match what's */
/*in the DTE header file (DTEngine.h).   */
/*---------------------------------------*/
#define DTE_EVAL_COLOR              0
#define DTE_EVAL_PERCENT            1
#define DTE_EVAL_ELEVATION          2
#define DTE_EVAL_DIFFUSE_LEVEL      3
#define DTE_EVAL_DIFFUSE_FUNC       4
#define DTE_EVAL_LUMINOSITY         5
#define DTE_EVAL_SPECULAR_LEVEL     6
#define DTE_EVAL_SPECULAR_FUNC      7
#define DTE_EVAL_SPECULAR_COLOR     8
#define DTE_EVAL_GLOSSINESS         9
#define DTE_EVAL_METAL_LEVEL        10
#define DTE_EVAL_ANISOTROPY         11
#define DTE_EVAL_ANISO_DIR          12
#define DTE_EVAL_REFLECTIVITY       13
#define DTE_EVAL_ENVIRONMENT        14
#define DTE_EVAL_TRANSPARENCY       15
#define DTE_EVAL_REFRACTION         16
#define DTE_EVAL_CC_LEVEL           17
#define DTE_EVAL_CC_GLOSSINESS      18
#define DTE_EVAL_CC_THICKNESS       19
#define DTE_EVAL_CC_SMOOTHNESS      20
#define DTE_EVAL_BUMP               21
#define DTE_EVAL_ALPHA              22

/*Make DSO function calls a bit nicer. */
/*-------------------------------------*/
#define SimRM_GetContextID(dtfile) \
        SimbiontRM(dtfile, P)

#define SimRM_ReleaseContextID(contextID) \
        SimbiontRM(contextID)

#define SimRM_SetTweakColor(contextID, name, value) \
        SimbiontRM(contextID, name, value)

#define SimRM_SetTweakFloat(contextID, name, value) \
        SimbiontRM(contextID, name, value)

#define SimRM_EvalColor(contextID, evalmask, point, normal, incident, samplesize, frame, cameraDistP, cRep, rRep) \
        SimbiontRM(contextID, evalmask, point, normal, incident, samplesize, frame, cameraDistP, cRep, rRep)

#define SimRM_EvalFloat(contextID, evalmask, point, normal, incident, samplesize, frame, cameraDistP, cRep, rRep) \
        SimbiontRM(contextID, point, evalmask, normal, incident, samplesize, frame, cameraDistP, cRep, rRep)

#define SimRM_EvalBump(contextID, evalmask, point, normal, incident, samplesize, frame, cameraDistP, cRep, rRep, bumpScale) \
        SimbiontRM(contextID, evalmask, point, normal, incident, samplesize, frame, cameraDistP, cRep, rRep, bumpScale)
