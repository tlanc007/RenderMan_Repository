#ifndef BRDF_H
#define BRDF_H 1

/*
 * Replacement for diffuse()
 * Only considers lights w/o a category
 */
color pickyDiffuse(normal N) {
	extern point P;
	color C = 0;
	illuminance("-*", P, N, PI/2) {
		uniform float nondiffuse = 0;
		lightsource("__nondiffuse", nondiffuse);
	    C += (1 - nondiffuse) * Cl * normalize(L) . N;
	}
	return C;
}

/*
 * Replacement for specular()
 * Only considers lights w/o a category
 */
color pickySpecular(normal N; vector V; float roughness) {
	extern point P;
	color C = 0;
	illuminance("-*", P, N, PI/2) {
		uniform float nonspecular = 0;
		lightsource("__nonspecular", nonspecular);
	    C += (1 - nonspecular) * Cl * specularbrdf(normalize(L), normalize(N), normalize(V), roughness);
	}
	return C;
}

#endif
