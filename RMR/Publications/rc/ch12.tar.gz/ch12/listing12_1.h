/* Copyrighted Pixar 1989 */
/* Used with listing12_1.c from the RenderMan Companion p.253 */

#define FILENAME "listing12_1.tiff"
#define PICXRES 256 
#define PICYRES 192
#define CROPMINX 0.0
#define CROPMAXX 1.0
#define CROPMINY 0.0
#define CROPMAXY 1.0
#define CAMXPOS 0.0
#define CAMYPOS 1.0
#define CAMZPOS -3.0
#define CAMXDIR 0.0
#define CAMYDIR 0.0
#define CAMZDIR 0.0
#define CAMROLL 0.0

#define CAMZOOM 0.7
