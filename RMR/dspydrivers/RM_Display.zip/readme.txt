RhinoMan: Display driver instructions and notes

1.  Place a copy of the file called "BTNexgenIPL32.dll" into the:
into your "Windows\system32" (for Win95/98) or 
the "WINNT\system32" (for NT and Win2000).  or
"BMRT\bin" folder.

Insert into your RIB file the following lines making sure the path is set to where you put the "d_RM_Display.so" file on your computer:

Option "render" "integer useprmandspy" [1]
Option "searchpath" "display" "C:/Program Files/RhinoMan/display/"
Display "Rendering_name.tif" "RM_Display" "rgba"


The driver accepts rgb or rgba output so you can specify either above.



